USE teams;

INSERT INTO games (match_date, victory, observations) VALUES ('2019-5-6', 1, "RAS");
INSERT INTO games (match_date, victory, observations) VALUES ('2019-5-7', 0, "Pas ouf");
INSERT INTO games (match_date, victory, observations) VALUES ('2019-5-8', 1, "RAS les gars");

